﻿using Microsoft.EntityFrameworkCore;
using RedisCore.DataAccess.DBContext;
using RedisCore.DataAccess.Interfaces;
using RedisCore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RedisCore.DataAccess.Classes
{
    public class CustomerRepository : ICustomerRepository
    {
        public readonly AppDbContext _appDbContext;
        public CustomerRepository(AppDbContext appDbContext)
        {
            this._appDbContext = appDbContext;
        }
        public async Task<IEnumerable<Customer>> GetCustomers()
        {
            Thread.Sleep (5000);
            return await _appDbContext.Customers
                .Include(c => c.Department)
                .ToListAsync();
        }

        public async Task<Customer> AddCustomer(Customer customer)
        {
            var result = await _appDbContext.Customers.AddAsync(customer);
            await _appDbContext.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Customer> GetCustomerById(int custid)
        {
            var result = await _appDbContext.Customers.
                Include(c => c.Department).
                FirstOrDefaultAsync(x => x.Id == custid);

            return result;
        }

        public async Task<Customer> GetCustomerByName(string firstName)
        {
            var result = await _appDbContext.Customers.
              Include(c => c.Department).
              FirstOrDefaultAsync(x => x.FirstName == firstName);

            return result;
        }

    }
}
