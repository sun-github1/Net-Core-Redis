﻿using RedisCore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisCore.DataAccess.Interfaces
{
    
    public interface ICustomerRepository
    {
        Task<IEnumerable<Customer>> GetCustomers();
        Task<Customer> GetCustomerById(int custid);
        Task<Customer> GetCustomerByName(string firstName);
        Task<Customer> AddCustomer(Customer customer);
    }
}
