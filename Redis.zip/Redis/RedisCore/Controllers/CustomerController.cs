﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using RedisCore.DataAccess.DBContext;
using RedisCore.DataAccess.Interfaces;
using RedisCore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RedisCore.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private ICustomerRepository customerRepository;
        private IMemoryCache memoryCache;
        private IDistributedCache distributedCache;
        public CustomerController(IMemoryCache memoryCache,
            ICustomerRepository customerRepository,
            IDistributedCache distributedCache)
        {
            this.customerRepository = customerRepository;
            this.memoryCache = memoryCache;
            this.distributedCache = distributedCache;
        }

        [HttpGet]
        public async Task<ActionResult> GetAllCustomers()
        {
            try
            {

                //using in memory cache
                //var cacheKey = "customerList";
                //if (!memoryCache.TryGetValue(cacheKey, out IEnumerable<Customer> customerList))
                //{
                //    Thread.Sleep(5000);
                //    customerList = await customerRepository.GetCustomers();
                //    var cacheExpiryOptions = new MemoryCacheEntryOptions
                //    {
                //        AbsoluteExpiration = DateTime.Now.AddMinutes(3),
                //        Priority = CacheItemPriority.High,
                //        SlidingExpiration = TimeSpan.FromMinutes(1)
                //    };
                //    memoryCache.Set(cacheKey, customerList, cacheExpiryOptions);
                //}
                //return Ok(customerList);
                string serializedCustomerList = "";
                string cacheKey = "customerList";
                IEnumerable<Customer> customerList = null;
                var redisCustomerList =await  distributedCache.GetAsync(cacheKey);
               
                if (redisCustomerList != null)
                {
                    serializedCustomerList = Encoding.UTF8.GetString(redisCustomerList);
                    customerList = JsonConvert.DeserializeObject<IEnumerable<Customer>>(serializedCustomerList);
                }
                else
                {
                    customerList = await customerRepository.GetCustomers();
                    serializedCustomerList = JsonConvert.SerializeObject(customerList);
                    redisCustomerList = Encoding.UTF8.GetBytes(serializedCustomerList);
                    
                    var options = new DistributedCacheEntryOptions()
                        .SetAbsoluteExpiration(DateTime.Now.AddMinutes(4))
                        .SetSlidingExpiration(TimeSpan.FromMinutes(2));
                    
                    await distributedCache.SetAsync(cacheKey, redisCustomerList, options);
                }
                return Ok(customerList);
                
               
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from database");
            }

        }

        [HttpGet("{custid:int}")]
        public async Task<ActionResult> GetCustomer(int custid)
        {
            try
            {
                return Ok(await customerRepository.GetCustomerById(custid));
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from database");
            }

        }

        [HttpPost]
        public async Task<ActionResult> AddCustomer([FromBody]Customer customer)
        {
            try
            {
                
                if (customer == null)
                {
                    return BadRequest();
                }

                var exitsingCust = await customerRepository.GetCustomerByName(customer.FirstName);

                if (exitsingCust != null)
                {
                    ModelState.AddModelError("FirstName", "Customer with same name alreday exists");
                    return BadRequest(ModelState);
                }

                var addedcust = await customerRepository.AddCustomer(customer);
                if (addedcust == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to add customer");
                }
                else
                {
                    //Add a Location header to the response. The Location header specifies the URI of the newly created employee object
                    return CreatedAtAction(nameof(GetCustomer),
                        new { custid = addedcust.Id },
                        addedcust);
                }

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error while adding customer");
            }

        }
    }
}
